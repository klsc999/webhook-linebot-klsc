# line-bot-demo

app.js
- Reply with two static messages

app2.js
- Echo reply

app3.js
- Reply using AIML 
